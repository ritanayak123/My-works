import "./App.css";
import React from "react";
//import { DataGrid, GridLinkOperator, GridToolbar } from "@mui/x-data-grid";
import {
  DataGridPro,
  GridLinkOperator,
  GridToolbar,
  GridColDef,
  GridApi,
  GridCellValue,
} from "@mui/x-data-grid-pro";
import Box from "@mui/material/Box";
import Stack from "@mui/material/Stack";
import Button from "@mui/material/Button";

function App() {
  let demoData = [
    {
      id: 0,
      title: "Tagtune",
      division: "Accounting",
      project_owner: "Kevin Snyder",
      budget: 20614.14,
      status: "archived",
      created: "09/14/2015",
      modified: "10/02/2015",
    },
    {
      id: 1,
      title: "Oyoyo",
      division: "Administration",
      project_owner: "Eugene Brown",
      budget: 22106.44,
      status: "new",
      created: "07/17/2015",
      modified: null,
    },
    {
      id: 2,
      title: "Lajo",
      division: "Marketing",
      project_owner: "Killgore Trout",
      budget: 15481.27,
      status: "working",
      created: "07/19/2015",
      modified: "09/17/2015",
    },
    {
      id: 3,
      title: "Blognation",
      division: "Administration",
      project_owner: "Richard Henry",
      budget: 24017.98,
      status: "working",
      created: "08/03/2015",
      modified: "09/17/2015",
    },
    {
      id: 4,
      title: "Vinte",
      division: "Administration",
      project_owner: "Michelle Webb",
      budget: 12935.84,
      status: "working",
      created: "08/05/2015",
      modified: "09/15/2015",
    },
    {
      id: 5,
      title: "Aibox",
      division: "Administration",
      project_owner: "Killgore Trout",
      budget: 15991.78,
      status: "working",
      created: "09/03/2015",
      modified: "10/02/2015",
    },
    {
      id: 61,
      title: "Buzzdog",
      division: "Administration",
      project_owner: "Michelle Webb",
      budget: 22610.09,
      status: "archived",
      created: "07/26/2015",
      modified: "10/01/2015",
    },
    {
      id: 6,
      title: "Plambee",
      division: "Sales",
      project_owner: "Michelle Webb",
      budget: 14229.02,
      status: "archived",
      created: "09/14/2015",
      modified: "10/01/2015",
    },
    {
      id: 7,
      title: "Photobug",
      division: "Administration",
      project_owner: "James Holden",
      budget: 10959.29,
      status: "working",
      created: "09/03/2015",
      modified: "09/18/2015",
    },
    {
      id: 8,
      title: "Quimm",
      division: "Marketing",
      project_owner: "James Holden",
      budget: 14139.38,
      status: "delivered",
      created: "08/02/2015",
      modified: "09/26/2015",
    },
    {
      id: 9,
      title: "Innojam",
      division: "Sales",
      project_owner: "Eugene Brown",
      budget: 24318.05,
      status: "working",
      created: "09/13/2015",
      modified: "09/20/2015",
    },
    {
      id: 10,
      title: "Jaxworks",
      division: "Production",
      project_owner: "Michelle Webb",
      budget: 15054.27,
      status: "new",
      created: "08/12/2015",
      modified: null,
    },
    {
      id: 11,
      title: "Skyble",
      division: "Accounting",
      project_owner: "Richard Henry",
      budget: 13810.1,
      status: "delivered",
      created: "07/12/2015",
      modified: "09/21/2015",
    },
    {
      id: 12,
      title: "Photobean",
      division: "Marketing",
      project_owner: "Michelle Webb",
      budget: 12637.95,
      status: "working",
      created: "08/24/2015",
      modified: "09/15/2015",
    },
    {
      id: 13,
      title: "Topicware",
      division: "Administration",
      project_owner: "Eugene Brown",
      budget: 9667.52,
      status: "working",
      created: "08/01/2015",
      modified: "09/29/2015",
    },
    {
      id: 14,
      title: "Buzzster",
      division: "Production",
      project_owner: "Nicole Smith",
      budget: 14657.54,
      status: "working",
      created: "08/09/2015",
      modified: "09/18/2015",
    },
    {
      id: 15,
      title: "Twinte",
      division: "Administration",
      project_owner: "Kevin Snyder",
      budget: 17729.37,
      status: "delivered",
      created: "09/09/2015",
      modified: "09/18/2015",
    },
    {
      id: 16,
      title: "Blognation",
      division: "Production",
      project_owner: "Eugene Brown",
      budget: 19540.82,
      status: "archived",
      created: "07/21/2015",
      modified: "09/22/2015",
    },
    {
      id: 17,
      title: "Flashdog",
      division: "Production",
      project_owner: "Michelle Webb",
      budget: 24870.61,
      status: "working",
      created: "07/05/2015",
      modified: "10/02/2015",
    },
    {
      id: 18,
      title: "Yakijo",
      division: "Accounting",
      project_owner: "Killgore Trout",
      budget: 23533.54,
      status: "working",
      created: "08/12/2015",
      modified: "10/01/2015",
    },
    {
      id: 19,
      title: "Quatz",
      division: "Sales",
      project_owner: "Richard Henry",
      budget: 23639.65,
      status: "archived",
      created: "07/19/2015",
      modified: "09/19/2015",
    },
    {
      id: 20,
      title: "Dabjam",
      division: "Marketing",
      project_owner: "Kevin Snyder",
      budget: 14356.55,
      status: "new",
      created: "08/22/2015",
      modified: null,
    },
    {
      id: 21,
      title: "Meetz",
      division: "Sales",
      project_owner: "Kevin Snyder",
      budget: 13882.22,
      status: "delivered",
      created: "08/26/2015",
      modified: "10/01/2015",
    },
    {
      id: 22,
      title: "Flipopia",
      division: "Marketing",
      project_owner: "Eugene Brown",
      budget: 10306.87,
      status: "delivered",
      created: "08/11/2015",
      modified: "09/17/2015",
    },
    {
      id: 23,
      title: "Quaxo",
      division: "Administration",
      project_owner: "Nicole Smith",
      budget: 13945.69,
      status: "archived",
      created: "07/13/2015",
      modified: "09/21/2015",
    },
    {
      id: 24,
      title: "Trunyx",
      division: "Production",
      project_owner: "Nicole Smith",
      budget: 23136.21,
      status: "delivered",
      created: "09/03/2015",
      modified: "09/19/2015",
    },
    {
      id: 25,
      title: "Dabtype",
      division: "Marketing",
      project_owner: "Richard Henry",
      budget: 22000.98,
      status: "archived",
      created: "08/26/2015",
      modified: "09/28/2015",
    },
    {
      id: 26,
      title: "Meetz",
      division: "Marketing",
      project_owner: "Eugene Brown",
      budget: 17620.23,
      status: "new",
      created: "09/08/2015",
      modified: null,
    },
    {
      id: 27,
      title: "Kimia",
      division: "Sales",
      project_owner: "Richard Henry",
      budget: 12061.73,
      status: "archived",
      created: "08/31/2015",
      modified: "09/29/2015",
    },
    {
      id: 28,
      title: "Dazzlesphere",
      division: "Accounting",
      project_owner: "Eugene Brown",
      budget: 21443.97,
      status: "archived",
      created: "07/20/2015",
      modified: "10/01/2015",
    },
  ];

  const VISSIBLE_FIELDS = [
    "title",
    "division",
    "project_owner",
    "budget",
    "status",
    "created",
    "modified",
  ];
  const columns = [
    {
      field: "title",
      headerName: "Title",
      width: 150,
      editable: true,
      renderCell: (params) => {
        const onClick = (e) => {
          e.stopPropagation(); // don't select this row after clicking

          const api = params.api;
          const thisRow = {};

          api
            .getAllColumns()
            .filter((c) => c.field !== "__check__" && !!c)
            .forEach(
              (c) => (thisRow[c.field] = params.getValue(params.id, c.field))
            );

          return alert("Navigate to another page logic");
        };

        return (
          <Button onClick={onClick}>
            {params.getValue(params.id, "title")}
          </Button>
        );
      },
    },
    {
      field: "division",
      headerName: "Division",
      width: 150,
      editable: true,
    },
    {
      field: "project_owner",
      headerName: "Project Owner",
      width: 150,
      editable: true,
    },
    {
      field: "budget",
      headerName: "Budget",
      width: 150,
      editable: true,
    },
    {
      field: "status",
      headerName: "Status",
      width: 150,
      editable: false,
    },
    {
      field: "created",
      headerName: "Created",
      width: 150,
      editable: false,
    },
    {
      field: "modified",
      headerName: "Modified",
      width: 150,
      editable: true,
    },
  ];

  const [rows, setRows] = React.useState(() => [...demoData]);

  const initialState = {
    filter: {
      filterModel: {
        items: [],
      },
    },
  };

  let idCounter = 28;

  const createRandomRow = () => {
    idCounter += 1;
    return {
      id: idCounter,
      title: "Dazzlesphere",
      division: "Accounting",
      project_owner: "Eugene Brown",
      budget: 21443.97,
      status: "archived",
      created: "07/20/2015",
      modified: "10/01/2015",
    };
  };

  const handleAddRow = () => {
    setRows((prevRows) => [...prevRows, createRandomRow()]);
  };

  return (
    <div style={{ height: 520, width: "100%" }}>
      <Stack
        sx={{ width: "100%", mb: 1 }}
        direction="row"
        alignItems="flex-start"
        columnGap={1}
      >
        <Button size="small" onClick={handleAddRow}>
          Add a row
        </Button>
      </Stack>
      <DataGridPro
        rows={rows}
        columns={columns}
        components={{
          Toolbar: GridToolbar,
        }}
        componentsProps={{
          filterPanel: {
            // Force usage of "And" operator
            linkOperators: [GridLinkOperator.And],
            // Display columns by ascending alphabetical order
            columnsSort: "asc",
            filterFormProps: {
              // Customize inputs by passing props
              linkOperatorInputProps: {
                variant: "outlined",
                size: "small",
              },
              columnInputProps: {
                variant: "outlined",
                size: "small",
                sx: { mt: "auto" },
              },
              operatorInputProps: {
                variant: "outlined",
                size: "small",
                sx: { mt: "auto" },
              },
              deleteIconProps: {
                sx: {
                  "& .MuiSvgIcon-root": { color: "#d32f2f" },
                },
              },
            },
            sx: {
              // Customize inputs using css selectors
              "& .MuiDataGrid-filterForm": { p: 2 },
              "& .MuiDataGrid-filterForm:nth-child(even)": {
                backgroundColor: (theme) =>
                  theme.palette.mode === "dark" ? "#444" : "#f5f5f5",
              },
              "& .MuiDataGrid-filterFormLinkOperatorInput": { mr: 2 },
              "& .MuiDataGrid-filterFormColumnInput": { mr: 2, width: 150 },
              "& .MuiDataGrid-filterFormOperatorInput": { mr: 2 },
              "& .MuiDataGrid-filterFormValueInput": { width: 200 },
            },
          },
        }}
        initialState={initialState}
      />
    </div>
  );
}

export default App;
